
export type StudentRecord = {
  id: string;
  source: string;
  rowNumber: number;
  data: Record<string, string>;
};

export type MatchCandidate = {
  id: string;
  left: StudentRecord;
  right: StudentRecord;
  score: number;
  reasons: string[];
  status: "Likely match" | "Review";
};

const aliases: Record<string, string[]> = {
  Name: [
    "name",
    "full name",
    "student name",
    "candidate name",
    "student full name",
    "alumni name"
  ],
  Email: [
    "email",
    "email id",
    "email address",
    "mail",
    "e-mail"
  ],
  Mobile: [
    "mobile",
    "phone",
    "phone number",
    "mobile number",
    "contact number",
    "telephone"
  ],
  "Roll No": [
    "roll no",
    "roll number",
    "usn",
    "student id",
    "registration number",
    "register number"
  ],
  Department: [
    "department",
    "dept",
    "branch",
    "course department",
    "program"
  ],
  "Graduation Year": [
    "graduation year",
    "passout year",
    "passing year",
    "year of graduation",
    "year of graduation (1)"
  ],
  City: ["city", "town"],
  State: ["state", "province", "region"],
  Country: ["country"],
  Degree: ["degree", "qualification", "degree (1)"]
};

export const standardFields = Object.keys(aliases);

export function normalizeHeader(header: string): string {
  return header
    .toLowerCase()
    .trim()
    .replace(/\s*\(\d+\)\s*$/, "")
    .replace(/[_-]+/g, " ")
    .replace(/\s+/g, " ");
}

export function canonicalHeader(header: string): string {
  const normalized = normalizeHeader(header);

  for (const [canonical, names] of Object.entries(aliases)) {
    if (
      names.some((name) => normalizeHeader(name) === normalized)
    ) {
      return canonical;
    }
  }

  return header.trim() || "Unnamed column";
}

export function normalizeValue(value: unknown): string {
  if (value === null || value === undefined) return "";

  return String(value)
    .trim()
    .replace(/\s+/g, " ");
}

export function normalizeRecords(
  records: StudentRecord[],
  mapping: Record<string, string>
): StudentRecord[] {
  return records.map((record) => {
    const data: Record<string, string> = {};

    for (const [original, value] of Object.entries(record.data)) {
      const mapped = mapping[original] || canonicalHeader(original);
      const key = mapped.trim() || original;

      // Preserve a nonempty value if multiple columns map to one field.
      if (!(key in data) || (!data[key] && value)) {
        data[key] = value;
      }
    }

    return { ...record, data };
  });
}

function valueFor(
  record: StudentRecord,
  field: string
): string {
  // Prefer the canonical key if normalization has already occurred.
  if (record.data[field] !== undefined) {
    return normalizeValue(record.data[field]);
  }

  const entry = Object.entries(record.data).find(
    ([key]) => canonicalHeader(key) === field
  );

  return normalizeValue(entry?.[1]);
}

function compact(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]/g, "");
}

export function similarity(a: string, b: string): number {
  const x = compact(a);
  const y = compact(b);

  if (!x || !y) return 0;
  if (x === y) return 1;

  // Save memory by keeping only two rows of the edit-distance matrix.
  let previous = Array.from(
    { length: y.length + 1 },
    (_, i) => i
  );

  for (let i = 1; i <= x.length; i++) {
    const current = new Array<number>(y.length + 1);
    current[0] = i;

    for (let j = 1; j <= y.length; j++) {
      const substitutionCost =
        x[i - 1] === y[j - 1] ? 0 : 1;

      current[j] = Math.min(
        previous[j] + 1,
        current[j - 1] + 1,
        previous[j - 1] + substitutionCost
      );
    }

    previous = current;
  }

  return (
    1 - previous[y.length] / Math.max(x.length, y.length)
  );
}

const MATCH_FIELDS = [
  { name: "Roll No", weight: 40, identifier: true },
  { name: "Mobile", weight: 35, identifier: true },
  { name: "Email", weight: 35, identifier: true },
  { name: "Name", weight: 25, identifier: false },
  { name: "Department", weight: 5, identifier: false },
  { name: "Graduation Year", weight: 5, identifier: false }
] as const;

function addToIndex(
  index: Map<string, number[]>,
  key: string,
  recordIndex: number
): void {
  const bucket = index.get(key);

  if (bucket) {
    bucket.push(recordIndex);
  } else {
    index.set(key, [recordIndex]);
  }
}

export function compareRecords(
  records: StudentRecord[],
  threshold = 60
): MatchCandidate[] {
  if (records.length < 2) return [];

  const index = new Map<string, number[]>();

  // Cache normalized field values so they aren't repeatedly calculated.
  const normalized = records.map((record) => {
    const values: Record<string, string> = {};

    for (const field of MATCH_FIELDS) {
      values[field.name] = valueFor(record, field.name);
    }

    return values;
  });

  // Index identifiers and name tokens to shortlist candidates.
  records.forEach((record, i) => {
    const values = normalized[i];

    for (const field of MATCH_FIELDS) {
      const raw = values[field.name];
      const token = compact(raw);

      if (!token) continue;

      if (field.identifier) {
        addToIndex(
          index,
          `${field.name}:${token}`,
          i
        );
      }

      if (field.name === "Name") {
        // Exact normalized names and shared name tokens.
        addToIndex(index, `name-exact:${token}`, i);

        if (token.length >= 4) {
          addToIndex(
            index,
            `name-prefix:${token.slice(0, 4)}`,
            i
          );
        }

        for (const word of raw.toLowerCase().split(/\s+/)) {
          const wordToken = compact(word);

          if (wordToken.length >= 4) {
            addToIndex(
              index,
              `name-word:${wordToken}`,
              i
            );
          }
        }
      }
    }
  });

  // Deduplicate candidate pairs across indexes.
  const pairs = new Set<string>();

  for (const bucket of index.values()) {
    if (bucket.length < 2) continue;

    for (let a = 0; a < bucket.length; a++) {
      const i = bucket[a];

      for (let b = a + 1; b < bucket.length; b++) {
        const j = bucket[b];

        // Only compare records from different files.
        if (records[i].source === records[j].source) {
          continue;
        }

        const leftIndex = Math.min(i, j);
        const rightIndex = Math.max(i, j);

        pairs.add(`${leftIndex}:${rightIndex}`);
      }
    }
  }

  const results: MatchCandidate[] = [];

  for (const pair of pairs) {
    const separator = pair.indexOf(":");
    const i = Number(pair.slice(0, separator));
    const j = Number(pair.slice(separator + 1));

    const left = records[i];
    const right = records[j];

    let points = 0;
    let availableWeight = 0;
    let conflictingStrongIds = 0;
    let exactStrongId = false;

    const reasons: string[] = [];

    for (const field of MATCH_FIELDS) {
      const a = normalized[i][field.name];
      const b = normalized[j][field.name];

      if (!a || !b) continue;

      availableWeight += field.weight;

      const sim = similarity(a, b);

      if (field.identifier && sim === 1) {
        exactStrongId = true;
      }

      if (field.identifier && sim < 0.85) {
        conflictingStrongIds++;
      }

      const accepted =
        sim === 1 ||
        (field.name === "Name" && sim >= 0.7) ||
        (!field.identifier && sim >= 0.85);

      if (accepted) {
        points +=
          field.weight * (field.identifier ? 1 : sim);

        reasons.push(
          sim === 1
            ? `Same ${field.name}`
            : `Similar ${field.name}`
        );
      }
    }

    if (availableWeight === 0 || reasons.length === 0) {
      continue;
    }

    let score = Math.round(
      (points / availableWeight) * 100
    );

    // Do not confidently accept fuzzy matches when identifiers conflict.
    if (conflictingStrongIds > 0 && !exactStrongId) {
      score = Math.min(score, 59);
    }

    if (score < threshold) continue;

    results.push({
      id: [left.id, right.id].sort().join("::"),
      left,
      right,
      score,
      reasons:
        conflictingStrongIds > 0
          ? [
              ...reasons,
              "Conflicting identifier(s)—review carefully"
            ]
          : reasons,
      status:
        score >= 80 &&
        (exactStrongId || reasons.includes("Same Name"))
          ? "Likely match"
          : "Review"
    });
  }

  return results.sort((a, b) => b.score - a.score);
}
