# Excel Data Matcher

A standalone Next.js application for comparing Excel/CSV files, filtering records, finding duplicate candidates, reviewing differences, and exporting results.

## Requirements

- Node.js 20.9 or newer (recommended)
- npm
- Windows + VS Code works fine

## Install and run

Open a terminal in this project folder:

```powershell
npm install
npm run dev
```

Open http://localhost:3000.

To check a production build:

```powershell
npm run build
npm start
```

## Features

- Import multiple `.xlsx`, `.xls`, and `.csv` files (first worksheet for Excel files)
- Consolidated record table with source file and original row number
- Search and filter by source and missing fields
- Common header normalization and editable column mapping
- Cross-file duplicate candidate matching using identifiers and fuzzy text similarity
- Adjustable matching threshold
- Side-by-side comparison with field differences highlighted
- Manual match/not-a-match review decisions during the current session
- Separate views for missing information and unmatched records
- Export filtered records to Excel/CSV and all match candidates plus review decisions to Excel
- No database, account, server-side upload, or external matching API

## Privacy and limitations

File contents are processed in the browser and are not sent to a matching service by this app. Do not deploy publicly with sensitive data without reviewing your hosting, access, and privacy requirements.

- Matching is pairwise and can become slow for very large files. Tens of thousands of records will need optimized candidate blocking/indexing.
- Only the first worksheet in each Excel file is imported.
- Matching currently compares records across different source files, not duplicates within the same file.
- Review decisions are held in React memory and reset when the page is refreshed. Export match review before closing.
- Scores are heuristic similarity scores, not probabilities or proof of identity.
- Excel files with unusual formatting, merged header rows, or multiple header lines may need preprocessing.

## Main files

- `src/app/page.tsx` — UI, imports, filters, review, exports
- `src/app/globals.css` — global styles
- `src/lib/matcher.ts` — column normalization and match scoring

This project is independent from any other application and contains no database configuration.
